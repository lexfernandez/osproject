fusermount -u sfs_root

