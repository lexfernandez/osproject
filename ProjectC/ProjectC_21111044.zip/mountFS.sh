~/Downloads/fuse-smallfs-master/bin/sfs floppya.img ./sfs_root -f -s
